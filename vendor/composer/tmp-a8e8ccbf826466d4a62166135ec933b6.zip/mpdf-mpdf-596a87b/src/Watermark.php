<?php

namespace Mpdf;

interface Watermark
{

}
